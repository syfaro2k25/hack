<?php
require('../config.php');
echo introLanguage();
?>