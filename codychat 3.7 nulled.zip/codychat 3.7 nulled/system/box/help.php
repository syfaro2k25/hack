<?php
require('../config_session.php');
?>
<div class="pad_box text_box">
	<?php echo loadPageData('help'); ?>
</div>