<?php
$nlang['like'] = 'הגיב לאחד מהפוסטים שלך';
$nlang['reply'] = 'הגיב על אחד מהפוסטים שלך';
$nlang['add_post'] = 'פרסם משהו על הקיר';
$nlang['accept_friend'] = 'קיבל את בקשת החברות שלך';
$nlang['word_mute'] = 'אתה הושתקת %delay% שימוש badword';
$nlang['flood_mute'] = 'החשבון שלך הושבת %delay% על הצפה';
$nlang['spam_mute'] = 'אתה הושתקת %delay% על הצפה';
$nlang['rank_change'] = 'הדרגה שלך שונתה אתה עכשיו %rank%';
$nlang['mute'] = 'הושתק בגלל %delay%';
$nlang['unmute'] = 'הוסרה ההשתקה מימך';
$nlang['name_change'] = 'שינה את השם שלך %data%';
?>