<?php
$hlang['flood_mute'] = 'Flood mute';
$hlang['word_mute'] = 'Woord mute';
$hlang['word_kick'] = 'Woord kick';
$hlang['spam_mute'] = 'Spam mute';
$hlang['spam_ban'] = 'Spam ban';
$hlang['mute'] = 'Mute';
$hlang['ban'] = 'Ban';
$hlang['kick'] = 'Kick';
?>