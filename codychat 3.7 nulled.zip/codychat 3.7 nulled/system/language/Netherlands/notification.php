<?php
$nlang['like'] = 'Heeft gereageerd op een van je berichten';
$nlang['reply'] = 'Heeft gereageerd op een van je post';
$nlang['add_post'] = 'Heeft iets op de wall gepost';
$nlang['accept_friend'] = 'Heeft je uitnodiging als vriend geaccepteerd';
$nlang['word_mute'] = 'Je heb een mute voor %delay% vanwege beledigende taalgebruik';
$nlang['flood_mute'] = 'Je account is gemute voor %delay% vanwege flooding';
$nlang['spam_mute'] = 'Je account is gemute voor %delay% vanwege spam';
$nlang['rank_change'] = 'Je account rank is veranderd je rank is nu %rank%';
$nlang['mute'] = 'Je bent gemute voor %delay%';
$nlang['unmute'] = 'Je account is geunmute';
$nlang['name_change'] = 'Heeft je gebruikernaam veranderd in %data%';
?>