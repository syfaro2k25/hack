<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow($cody["can_manage_addons"])) {
    exit;
}
echo elementTitle($lang["addons_management"]);
echo "<div class=\"page_full\">\r\n\t<div class=\"page_element\">\r\n\t\t<div id=\"addons_list\">\r\n\t\t";
echo adminaddonslist();
echo "\t\t</div>\r\n\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'addonsblocked')
// Encryption type: 1
function adminAddonsList()
{
    global $mysqli;
    global $lang;
    $addons_list = "";
    $avail_update = 0;
    $dir = glob(BOOM_PATH . "/addons/*", GLOB_ONLYDIR);
    foreach ($dir as $dirnew) {
        $install = 0;
        $addon = str_replace(BOOM_PATH . "/addons/", "", $dirnew);
        if (file_exists(BOOM_PATH . "/addons/" . $addon . "/system/install.php")) {
            $avail_update++;
            $checkaddons = $mysqli->query("SELECT * FROM boom_addons WHERE addons = '" . $addon . "'");
            if (0 < $checkaddons->num_rows) {
                $addons = $checkaddons->fetch_assoc();
                $addons_list .= boomTemplate("element/addons_uninstall", $addons);
            } else {
                $addons_list .= boomTemplate("element/addons_install", $addon);
            }
        }
    }
    if (0 < $avail_update) {
        return $addons_list;
    }
    return emptyZone($lang["no_addons"]);
}

?>