<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(11)) {
    exit;
}
echo elementTitle($lang["update_zone"]);
echo "<div class=\"page_full\">\r\n\t<div class=\"page_element\">\r\n\t\t<div id=\"update_list\">\r\n\t\t";
echo getupdatelist();
echo "\t\t</div>\r\n\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'lockupdate')
// Encryption type: 1
function getUpdateList()
{
    global $mysqli;
    global $data;
    global $lang;
    $update_list = "";
    $avail_update = 0;
    $dir = glob(BOOM_PATH . "/updates/*", GLOB_ONLYDIR);
    foreach ($dir as $dirnew) {
        $update = str_replace(BOOM_PATH . "/updates/", "", $dirnew);
        if ($data["version"] < $update && is_numeric($update)) {
            $avail_update++;
            $update_list .= boomTemplate("element/update_element", $update);
        }
    }
    if (0 < $avail_update) {
        return "<div>" . $update_list . "</div>";
    }
    return emptyZone($lang["no_update"]);
}

?>