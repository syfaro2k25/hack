<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(9)) {
    exit;
}
echo elementTitle($lang["filter"]);
echo "<div class=\"page_full\">\r\n\t<div>\t\t\r\n\t\t<div class=\"tab_menu\">\r\n\t\t\t<ul>\r\n\t\t\t\t<li class=\"tab_menu_item tab_selected\" data=\"filter_tab\" data-z=\"word_filter\">";
echo $lang["bad_word_filter"];
echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"filter_tab\" data-z=\"spam_filter\">Spam</li>\r\n\t\t\t\t";
if (boomAllow(10)) {
    echo "\t\t\t\t<li class=\"tab_menu_item\" data=\"filter_tab\" data-z=\"username_filter\">";
    echo $lang["username"];
    echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"filter_tab\" data-z=\"email_filter\">";
    echo $lang["email"];
    echo "</li>\r\n\t\t\t\t";
}
echo "\t\t\t</ul>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"filter_tab\">\r\n\t\t<div id=\"word_filter\" class=\"tab_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t";
if (boomAllow(10)) {
    echo "\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t<p class=\"label\">";
    echo $lang["do_action"];
    echo "</p>\r\n\t\t\t\t\t<select id=\"set_word_action\" onchange=\"checkWordFilter();setWordAction();\">\r\n\t\t\t\t\t\t<option ";
    if ($data["word_action"] == 0) {
        echo "selected";
    }
    echo " value=\"0\">";
    echo $lang["action_none"];
    echo "</option>\r\n\t\t\t\t\t\t<option ";
    if ($data["word_action"] == 2) {
        echo "selected";
    }
    echo " value=\"2\">";
    echo $lang["mute"];
    echo "</option>\r\n\t\t\t\t\t\t<option ";
    if ($data["word_action"] == 3) {
        echo "selected";
    }
    echo " value=\"3\">";
    echo $lang["kick"];
    echo "</option>\r\n\t\t\t\t\t</select>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div id=\"word_action_delay\" class=\"setting_element ";
    echo hidefilters($data["word_action"], [2, 3]);
    echo "\">\r\n\t\t\t\t\t<p class=\"label\">";
    echo $lang["duration"];
    echo "</p>\r\n\t\t\t\t\t<select id=\"set_word_delay\" onchange=\"setWordAction();\">\r\n\t\t\t\t\t\t";
    echo optionMinutes($data["word_delay"], [1, 2, 5, 10, 15, 30, 60]);
    echo "\t\t\t\t\t</select>\r\n\t\t\t\t</div>\r\n\t\t\t\t";
}
echo "\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t<p class=\"label\">";
echo $lang["add_word"];
echo "</p>\r\n\t\t\t\t\t<input id=\"word_add\" class=\"full_input\"/>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"tpad5\">\r\n\t\t\t\t\t<button id=\"add_word\" onclick=\"addWord('word', 'badword_list', 'word_add');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-plus-circle\"></i> ";
echo $lang["add"];
echo "</button>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div id=\"badword_list\">\r\n\t\t\t\t\t";
echo listfilter("word");
echo "\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div id=\"spam_filter\" class=\"tab_zone hide_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t";
if (boomAllow(10)) {
    echo "\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t<p class=\"label\">";
    echo $lang["do_action"];
    echo "</p>\r\n\t\t\t\t\t<select id=\"set_spam_action\" onchange=\"checkSpamFilter();setSpamAction();\">\r\n\t\t\t\t\t\t<option ";
    if ($data["spam_action"] == 0) {
        echo "selected";
    }
    echo " value=\"0\">";
    echo $lang["action_none"];
    echo "</option>\r\n\t\t\t\t\t\t<option ";
    if ($data["spam_action"] == 1) {
        echo "selected";
    }
    echo " value=\"1\">";
    echo $lang["mute"];
    echo "</option>\r\n\t\t\t\t\t\t<option ";
    if ($data["spam_action"] == 2) {
        echo "selected";
    }
    echo " value=\"2\">";
    echo $lang["ban"];
    echo "</option>\r\n\t\t\t\t\t</select>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div id=\"spam_action_delay\" class=\"setting_element ";
    echo hidefilters($data["spam_action"], [1]);
    echo "\">\r\n\t\t\t\t\t<p class=\"label\">";
    echo $lang["duration"];
    echo "</p>\r\n\t\t\t\t\t<select id=\"set_spam_delay\" onchange=\"setSpamAction();\">\r\n\t\t\t\t\t\t";
    echo optionMinutes($data["spam_delay"], [5, 10, 15, 30, 60, 180, 1440, 10080]);
    echo "\t\t\t\t\t</select>\r\n\t\t\t\t</div>\r\n\t\t\t\t";
}
echo "\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t<p class=\"label\">";
echo $lang["add_word"];
echo "</p>\r\n\t\t\t\t\t<input id=\"spam_add\" class=\"full_input\"/>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"tpad5\">\r\n\t\t\t\t\t<button id=\"add_spam\" onclick=\"addWord('spam', 'spam_list', 'spam_add');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-plus-circle\"></i> ";
echo $lang["add"];
echo "</button>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div id=\"spam_list\">\r\n\t\t\t\t\t";
echo listfilter("spam");
echo "\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t";
if (boomAllow(10)) {
    echo "\t\t<div id=\"username_filter\" class=\"tab_zone hide_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
    echo $lang["add_word"];
    echo "</p>\r\n\t\t\t\t\t\t<input id=\"username_add\" class=\"full_input\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"tpad5\">\r\n\t\t\t\t\t<button id=\"add_username_filter\" onclick=\"addWord('username', 'name_list', 'username_add');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-plus-circle\"></i> ";
    echo $lang["add"];
    echo "</button>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div id=\"name_list\">\r\n\t\t\t\t\t";
    echo listfilter("username");
    echo "\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div id=\"email_filter\" class=\"tab_zone hide_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
    echo $lang["email_filter"];
    echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_email_filter\" onchange=\"setEmailFilter();\">\r\n\t\t\t\t\t\t\t";
    echo yesNo($data["email_filter"]);
    echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
    echo $lang["add_word"];
    echo "</p>\r\n\t\t\t\t\t\t<input id=\"email_add\" class=\"full_input\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class=\"tpad5\">\r\n\t\t\t\t\t<button id=\"add_email_filter\" onclick=\"addWord('email', 'email_list', 'email_add');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-plus-circle\"></i> ";
    echo $lang["add"];
    echo "</button>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div id=\"email_list\">\r\n\t\t\t\t\t";
    echo listfilter("email");
    echo "\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t";
}
echo "\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'filterlist')
// Encryption type: 2
function listFilter($type)
{
    global $data;
    global $mysqli;
    global $lang;
    $list_word = "";
    $getword = $mysqli->query("SELECT * FROM boom_filter WHERE word_type = '" . $type . "' ORDER BY word ASC");
    if (0 < $getword->num_rows) {
        while ($word = $getword->fetch_assoc()) {
            $list_word .= boomTemplate("element/word", $word);
        }
    } else {
        $list_word .= emptyZone($lang["empty"]);
    }
    return $list_word;
}
function hideFilters($val, $val2)
{
    if (!in_array($val, $val2)) {
        return "hidden";
    }
}

?>