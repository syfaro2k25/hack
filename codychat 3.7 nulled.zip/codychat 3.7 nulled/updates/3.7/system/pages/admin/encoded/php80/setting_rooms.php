<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(10)) {
    exit;
}
echo elementTitle($lang["room_management"]);
echo "<div class=\"page_full\">\r\n\t<div class=\"page_element\">\r\n\t\t<div id=\"rooms_list\">\r\n\t\t\t";
if (canRoom()) {
    echo "\t\t\t<div class=\"admin_add_room\">\r\n\t\t\t\t<button onclick=\"adminCreateRoom();\" class=\"reg_button theme_btn\"><i class=\"fa fa-plus-circle\"></i> ";
    echo $lang["add_room"];
    echo "</button>\r\n\t\t\t</div>\r\n\t\t\t";
}
echo "\t\t\t<div id=\"rom_search\" class=\"vpad15\">\r\n\t\t\t\t<div class=\"search_bar\">\r\n\t\t\t\t\t<input id=\"search_admin_room\" placeholder=\"&#xf002;\" class=\"full_input\" type=\"text\"/>\r\n\t\t\t\t\t<div class=\"clear\"></div>\r\n\t\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t<div id=\"room_listing\">\r\n\t\t\t\t";
echo adminroomlist();
echo "\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'roomlisting')
// Encryption type: 5
function adminRoomList()
{
    global $mysqli;
    global $lang;
    $list_rooms = "";
    $getrooms = $mysqli->query("SELECT boom_rooms.*\r\n\tFROM boom_rooms \r\n\tORDER BY room_name ASC");
    if (0 < $getrooms->num_rows) {
        while ($room = $getrooms->fetch_assoc()) {
            $list_rooms .= boomTemplate("element/admin_room", $room);
        }
    } else {
        $list_rooms .= emptyZone($lang["empty"]);
    }
    return $list_rooms;
}

?>