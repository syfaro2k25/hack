<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(11)) {
    exit;
}
echo elementTitle($lang["page"]);
echo "<div class=\"page_full\">\r\n\t<div>\t\t\r\n\t\t<div class=\"tab_menu\">\r\n\t\t\t<ul>\r\n\t\t\t\t<li class=\"tab_menu_item tab_selected\" data=\"filter_tab\" data-z=\"privacy_policy\">";
echo $lang["privacy"];
echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"filter_tab\" data-z=\"terms_of_use\">";
echo $lang["rules"];
echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"filter_tab\" data-z=\"help\">";
echo $lang["help"];
echo "</li>\r\n\t\t\t</ul>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"filter_tab\">\r\n\t\t<div id=\"privacy_policy\" class=\"tab_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t <textarea id=\"privacy_text\"  class=\"bmargin10 full_textarea edit_page_box\">";
echo loadPageData("privacy_policy");
echo "</textarea>\r\n\t\t\t\t<button id=\"add_word\" onclick=\"savePageData('privacy_policy', 'privacy_text');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-save\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div id=\"terms_of_use\" class=\"tab_zone hide_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t <textarea id=\"terms_text\" class=\"bmargin10 full_textarea edit_page_box\">";
echo loadPageData("terms_of_use");
echo "</textarea>\r\n\t\t\t\t<button id=\"add_word\" onclick=\"savePageData('terms_of_use', 'terms_text');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-save\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div id=\"help\" class=\"tab_zone hide_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t <textarea id=\"help_text\" class=\"bmargin10 full_textarea edit_page_box\">";
echo loadPageData("help");
echo "</textarea>\r\n\t\t\t\t<button id=\"add_word\" onclick=\"savePageData('help', 'help_text');\" type=\"button\" class=\"reg_button theme_btn\"><i class=\"fa fa-save\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>";

?>