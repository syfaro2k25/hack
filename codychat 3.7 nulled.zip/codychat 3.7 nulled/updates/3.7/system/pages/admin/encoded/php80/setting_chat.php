<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(10)) {
    exit;
}
echo elementTitle($lang["chat_settings"]);
echo "<div class=\"page_full\">\r\n\t<div class=\"page_element\">\r\n\t\t<div class=\"boom_form\">\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["show_logs"];
echo "</p>\r\n\t\t\t\t<select id=\"set_allow_logs\">\r\n\t\t\t\t\t";
echo yesNo($data["allow_logs"]);
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["gender_icon"];
echo "</p>\r\n\t\t\t\t<select id=\"set_gender_ico\">\r\n\t\t\t\t\t";
echo yesNo($data["gender_ico"]);
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["flag_ico"];
echo "</p>\r\n\t\t\t\t<select id=\"set_flag_ico\">\r\n\t\t\t\t\t";
echo yesNo($data["flag_ico"]);
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["max_main"];
echo "</p>\r\n\t\t\t\t<select id=\"set_max_main\">\r\n\t\t\t\t\t";
echo optionCount($data["max_main"], 100, 1000, 100, "");
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["max_private"];
echo "</p>\r\n\t\t\t\t<select id=\"set_max_private\">\r\n\t\t\t\t\t";
echo optionCount($data["max_private"], 100, 500, 50, "");
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["max_offcount"];
echo "</p>\r\n\t\t\t\t<select id=\"set_max_offcount\">\r\n\t\t\t\t\t";
echo optionCount($data["max_offcount"], 0, 100, 5, "");
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["speed"];
echo "</p>\r\n\t\t\t\t<select id=\"set_speed\">\r\n\t\t\t\t\t";
echo optionCount($data["speed"], 1500, 10000, 500, "ms");
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<button data=\"chat\" type=\"button\" class=\"save_admin reg_button theme_btn \"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t</div>\r\n</div>";

?>