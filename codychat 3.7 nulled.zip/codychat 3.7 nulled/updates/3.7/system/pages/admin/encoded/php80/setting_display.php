<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(10)) {
    exit;
}
echo elementTitle($lang["display_settings"]);
echo "<div class=\"page_full\">\r\n\t<div class=\"page_element\">\r\n\t\t<div class=\"boom_form\">\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["theme"];
echo "</p>\r\n\t\t\t\t<select id=\"set_main_theme\">\r\n\t\t\t\t\t";
echo listTheme($data["default_theme"], 1);
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["login_page"];
echo "</p>\r\n\t\t\t\t<select id=\"set_login_page\">\r\n\t\t\t\t\t";
echo listlogin();
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<button data=\"display\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'loginlist')
// Encryption type: 4
function listLogin()
{
    global $data;
    global $lang;
    $login_list = "";
    $dir = glob(BOOM_PATH . "/control/login/*", GLOB_ONLYDIR);
    foreach ($dir as $dirnew) {
        $login = str_replace(BOOM_PATH . "/control/login/", "", $dirnew);
        if (file_exists(BOOM_PATH . "/control/login/" . $login . "/login.php")) {
            $login_list .= "<option " . selCurrent($data["login_page"], $login) . " value=\"" . $login . "\">" . $login . "</option>";
        }
    }
    return $login_list;
}

?>