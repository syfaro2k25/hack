<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(8)) {
    exit;
}
echo elementTitle($lang["manage_action"]);
echo "<div class=\"page_full\">\r\n\t<div>\t\t\r\n\t\t<div class=\"tab_menu\"> <ul> \t<li class=\"tab_menu_item tab_selected\" data=\"action_filter\" data-z=\"muted_filter\">";
echo $lang["muted"];
echo "</li> \t";
if (canKick()) {
    echo "\t\t\t\t<li class=\"tab_menu_item\" data=\"action_filter\" data-z=\"kicked_filter\">";
    echo $lang["kicked"];
    echo "</li> \t";
}
echo "\t\t\t\t";
if (canBan()) {
    echo "\t\t\t\t<li class=\"tab_menu_item\" data=\"action_filter\" data-z=\"banned_filter\">";
    echo $lang["banned"];
    echo "</li> \t";
}
echo "\t\t\t</ul>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"action_filter\">\r\n\t\t<div id=\"muted_filter\" class=\"tab_zone\"> <div class=\"page_element\"> \t<div id=\"action_muted_list\"> \t\t";
echo getActionList("muted");
echo "\t\t\t\t</div> </div>\r\n\t\t</div>\r\n\t\t";
if (canKick()) {
    echo "\t\t<div id=\"kicked_filter\" class=\"hide_zone tab_zone\"> <div class=\"page_element\"> \t<div id=\"action_muted_list\"> \t\t";
    echo getActionList("kicked");
    echo "\t\t\t\t</div> </div>\r\n\t\t</div>\r\n\t\t";
}
echo "\t\t";
if (canBan()) {
    echo "\t\t<div id=\"banned_filter\" class=\"tab_zone hide_zone\"> <div class=\"page_element\"> \t<div id=\"action_banned_list\"> \t\t";
    echo getActionList("banned");
    echo "\t\t\t\t</div> </div>\r\n\t\t</div>\r\n\t\t";
}
echo "\t</div>\r\n</div>";

?>