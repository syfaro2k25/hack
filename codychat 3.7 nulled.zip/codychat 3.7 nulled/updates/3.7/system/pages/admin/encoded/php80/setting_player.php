<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(10)) {
    exit;
}
echo elementTitle($lang["player_settings"]);
echo "<div class=\"page_full\">\r\n\t<div class=\"page_element\">\r\n\t\t<div class=\"boom_form\">\r\n\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t<p class=\"label\">";
echo $lang["default_stream"];
echo "</p>\r\n\t\t\t\t<select id=\"set_default_player\">\r\n\t\t\t\t\t";
echo adminPlayer($data["player_id"], 2);
echo "\t\t\t\t</select>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<button data=\"player\"  type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t<button type=\"button\" onclick=\"openAddPlayer();\" class=\"reg_button default_btn\"><i class=\"fa fa-plus-circle\"></i> ";
echo $lang["add_player_stream"];
echo "</button>\r\n\t</div>\r\n\t<div class=\"page_element\">\r\n\t\t<div id=\"admiN_stream_list\">\r\n\t\t\t";
echo liststreamplayer();
echo "\t\t</div>\r\n\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'streaming')
// Encryption type: 4
function listStreamPlayer()
{
    global $mysqli;
    global $lang;
    global $data;
    $stream_list = "";
    $getstream = $mysqli->query("SELECT * FROM boom_radio_stream ORDER BY stream_alias ASC");
    if (0 < $getstream->num_rows) {
        while ($stream = $getstream->fetch_assoc()) {
            $stream["default"] = "";
            if ($stream["id"] == $data["player_id"]) {
                $stream["default"] = "<div class=\"sub_list_selected\"><i class=\"fa fa-circle success\"></i></div>";
            }
            $stream_list .= boomTemplate("element/stream_player", $stream);
        }
    } else {
        $stream_list .= emptyZone($lang["empty"]);
    }
    return $stream_list;
}

?>