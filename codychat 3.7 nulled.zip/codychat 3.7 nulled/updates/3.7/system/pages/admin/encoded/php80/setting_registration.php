<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(10)) {
    exit;
}
echo elementTitle($lang["registration_settings"]);
echo "<div class=\"page_full\">\r\n\t<div>\t\t\r\n\t\t<div class=\"tab_menu\">\r\n\t\t\t<ul>\r\n\t\t\t\t<li class=\"tab_menu_item tab_selected\" data=\"rtab\" data-z=\"main_registration\">";
echo $lang["main"];
echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"rtab\" data-z=\"guest_registration\">";
echo $lang["guest"];
echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"rtab\" data-z=\"social_registration\">";
echo $lang["social"];
echo "</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"rtab\" data-z=\"bridge_registration\">Bridge</li>\r\n\t\t\t\t<li class=\"tab_menu_item\" data=\"rtab\" data-z=\"security_registration\">Security</li>\r\n\t\t\t</ul>\r\n\t\t</div>\r\n\t</div>\r\n\t<div class=\"page_element\">\r\n\t\t<div id=\"rtab\">\r\n\t\t\t<div id=\"main_registration\" class=\"tab_zone\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["allow_registration"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_registration\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["registration"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["regmute"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_regmute\">\r\n\t\t\t\t\t\t\t<option value=\"0\">";
echo $lang["off"];
echo "</option>\r\n\t\t\t\t\t\t\t";
echo optionMinutes($data["regmute"], [2, 5, 10, 15, 20, 25, 30, 45, 60, 120]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["validate"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_activation\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["activation"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["max_name"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_max_username\">\r\n\t\t\t\t\t\t\t";
echo optionCount($data["max_username"], 4, 20, 1, "");
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["min_age"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_min_age\">\r\n\t\t\t\t\t\t\t";
echo optionCount($data["min_age"], 9, 99, 1, "");
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"registration\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t\t<div id=\"guest_registration\" class=\"hide_zone tab_zone\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["allow_guest"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_allow_guest\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["allow_guest"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["guest_form"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_guest_form\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["guest_form"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["guest_talk"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_guest_talk\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["guest_talk"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"guest\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t\t<div id=\"bridge_registration\" class=\" hide_zone tab_zone\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["bridge"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_use_bridge\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["use_bridge"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"bridge_registration\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t\t<div id=\"social_registration\" class=\"hide_zone tab_zone\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\"><i class=\"fa fbook fa-facebook-square\"></i> ";
echo processsocial("Facebook", 1);
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_facebook_login\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["facebook_login"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t<p class=\"sub_text sub_label\"><i class=\"fa fa-globe theme_color\"></i> ";
echo $data["domain"];
echo "/login/facebook_login.php</p>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo processsocial("Facebook", 2);
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_facebook_id\" class=\"full_input\" value=\"";
echo $data["facebook_id"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo processsocial("Facebook", 3);
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_facebook_secret\" class=\"full_input\" value=\"";
echo $data["facebook_secret"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"clear15\"></div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\"><i class=\"fa gplus fa-google-plus\"></i> ";
echo processsocial("Google", 1);
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_google_login\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["google_login"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t<p class=\"sub_text sub_label\"><i class=\"fa fa-globe theme_color\"></i> ";
echo $data["domain"];
echo "/login/google_login.php</p>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo processsocial("Google", 2);
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_google_id\" class=\"full_input\" value=\"";
echo $data["google_id"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo processsocial("Google", 3);
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_google_secret\" class=\"full_input\" value=\"";
echo $data["google_secret"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"clear15\"></div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\"><i class=\"fa twit fa-twitter\"></i> ";
echo processsocial("Twitter", 1);
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_twitter_login\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["twitter_login"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t\t<p class=\"sub_text sub_label\"><i class=\"fa fa-globe theme_color\"></i> ";
echo $data["domain"];
echo "/login/twitter_login.php</p>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo processsocial("Twitter", 2);
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_twitter_id\" class=\"full_input\" value=\"";
echo $data["twitter_id"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo processsocial("Twitter", 3);
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_twitter_secret\" class=\"full_input\" value=\"";
echo $data["twitter_secret"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"social_registration\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t\t<div id=\"security_registration\" class=\"hide_zone tab_zone\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["use_recapt"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_use_recapt\">\r\n\t\t\t\t\t\t\t";
echo yesNo($data["use_recapt"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["recapt_site"];
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_recapt_key\" class=\"full_input\" value=\"";
echo $data["recapt_key"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["recapt_secret"];
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_recapt_secret\" class=\"full_input\" value=\"";
echo $data["recapt_secret"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"security_registration\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t</div>\r\n</div>";
// @ioncube.dynamickey encoding key: boommerge('boom', 'socialprocess')
// Encryption type: 5
function processSocial($t, $m)
{
    global $lang;
    if ($m == 1) {
        return str_replace("%type%", $t, $lang["social_login"]);
    }
    if ($m == 2) {
        return str_replace("%type%", $t, $lang["social_id"]);
    }
    if ($m == 3) {
        return str_replace("%type%", $t, $lang["social_secret"]);
    }
}

?>