<?php
 /*
 * @ https://CodyChat.co 
 * @ version: 3.1
 * @ Release: 01/09/2021
 */

require __DIR__ . "/../../../../config_session.php";
if (!boomAllow(10)) {
    exit;
}
echo elementTitle($lang["main_settings"]);
echo "<div class=\"page_full\">\r\n\t<div>\t\t\r\n\t\t<div class=\"tab_menu\">\r\n\t\t\t<ul>\r\n\t\t\t\t<li class=\"tab_menu_item tab_selected\" data=\"main_tab\" data-z=\"main_zone\">";
echo $lang["main"];
echo "</li>\r\n\t\t\t\t";
if (boomAllow(11)) {
    echo "\t\t\t\t<li class=\"tab_menu_item\" data=\"main_tab\" data-z=\"maint_zone\">";
    echo $lang["maintenance"];
    echo "</li>\r\n\t\t\t\t";
}
echo "\t\t\t</ul>\r\n\t\t</div>\r\n\t</div>\r\n\t<div id=\"main_tab\">\r\n\t\t<div id=\"main_zone\" class=\"tab_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["index_path"];
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_index_path\" class=\"full_input\" value=\"";
echo $data["domain"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["site_title"];
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_title\" class=\"full_input\" value=\"";
echo $data["title"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["site_description"];
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_site_description\" class=\"full_input\" value=\"";
echo $data["site_description"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element\">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["site_keyword"];
echo "</p>\r\n\t\t\t\t\t\t<input id=\"set_site_keyword\" class=\"full_input\" value=\"";
echo $data["site_keyword"];
echo "\" type=\"text\"/>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["timezone"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_timezone\">\r\n\t\t\t\t\t\t\t";
echo getTimezone($data["timezone"]);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
echo $lang["default_language"];
echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_default_language\">\r\n\t\t\t\t\t\t\t";
echo listLanguage($data["language"], 1);
echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"main_settings\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
echo $lang["save"];
echo "</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t";
if (boomAllow(11)) {
    echo "\t\t<div id=\"maint_zone\" class=\"tab_zone hide_zone\">\r\n\t\t\t<div class=\"page_element\">\r\n\t\t\t\t<div class=\"boom_form\">\r\n\t\t\t\t\t<div class=\"setting_element \">\r\n\t\t\t\t\t\t<p class=\"label\">";
    echo $lang["maint_mode"];
    echo "</p>\r\n\t\t\t\t\t\t<select id=\"set_maint_mode\">\r\n\t\t\t\t\t\t\t";
    echo onOff($data["maint_mode"]);
    echo "\t\t\t\t\t\t</select>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<button data=\"maintenance\" type=\"button\" class=\"save_admin reg_button theme_btn\"><i class=\"fa fa-floppy-o\"></i> ";
    echo $lang["save"];
    echo "</button>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t";
}
echo "\t</div>\r\n</div>";

?>