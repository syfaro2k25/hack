<?php
$mysqli->query("UPDATE boom_setting SET version = '3.7' WHERE id > 0");
?>